//jpms:bc
/*----------------------------------------------------------------------------*\
 * File:        cpf_config.cc
 *
 * Description: 
 *
 * Author:      jpms
 *
 *                                     Copyright (c) 2015, Joao Marques-Silva
\*----------------------------------------------------------------------------*/
//jpms:ec

#include "cpf_config.hh"

CPFConfig* CPFConfig::_instance = NULL;

/*----------------------------------------------------------------------------*/
