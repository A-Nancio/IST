//jpms:bc
/*----------------------------------------------------------------------------*\
 * File:        toolcfg.hh
 *
 * Description: 
 *
 * Author:      jpms
 * 
 *                                     Copyright (c) 2015, Joao Marques-Silva
\*----------------------------------------------------------------------------*/
//jpms:ec

#ifndef _TOOLCFG_H
#define _TOOLCFG_H 1

static const string toolname = "chkcpf";
static const string authorname = "Joao Marques-Silva";

#endif /* _TOOLCFG_H */

/*----------------------------------------------------------------------------*/
